# Generated from SSgrammar.g4 by ANTLR 4.6
from antlr4 import *
if __name__ is not None and "." in __name__:
    from .SSgrammarParser import SSgrammarParser
else:
    from SSgrammarParser import SSgrammarParser

# This class defines a complete generic visitor for a parse tree produced by SSgrammarParser.

class SSgrammarVisitor(ParseTreeVisitor):

    # Visit a parse tree produced by SSgrammarParser#prog.
    def visitProg(self, ctx:SSgrammarParser.ProgContext):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by SSgrammarParser#printStr.
    def visitPrintStr(self, ctx:SSgrammarParser.PrintStrContext):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by SSgrammarParser#printExpr.
    def visitPrintExpr(self, ctx:SSgrammarParser.PrintExprContext):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by SSgrammarParser#assign.
    def visitAssign(self, ctx:SSgrammarParser.AssignContext):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by SSgrammarParser#assignStr.
    def visitAssignStr(self, ctx:SSgrammarParser.AssignStrContext):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by SSgrammarParser#assignList.
    def visitAssignList(self, ctx:SSgrammarParser.AssignListContext):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by SSgrammarParser#newLine.
    def visitNewLine(self, ctx:SSgrammarParser.NewLineContext):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by SSgrammarParser#EOF.
    def visitEOF(self, ctx:SSgrammarParser.EOFContext):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by SSgrammarParser#MODOP.
    def visitMODOP(self, ctx:SSgrammarParser.MODOPContext):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by SSgrammarParser#parens.
    def visitParens(self, ctx:SSgrammarParser.ParensContext):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by SSgrammarParser#ANDOR.
    def visitANDOR(self, ctx:SSgrammarParser.ANDORContext):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by SSgrammarParser#dec.
    def visitDec(self, ctx:SSgrammarParser.DecContext):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by SSgrammarParser#EQNE.
    def visitEQNE(self, ctx:SSgrammarParser.EQNEContext):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by SSgrammarParser#listStart.
    def visitListStart(self, ctx:SSgrammarParser.ListStartContext):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by SSgrammarParser#MulDiv.
    def visitMulDiv(self, ctx:SSgrammarParser.MulDivContext):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by SSgrammarParser#AddSub.
    def visitAddSub(self, ctx:SSgrammarParser.AddSubContext):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by SSgrammarParser#notVal.
    def visitNotVal(self, ctx:SSgrammarParser.NotValContext):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by SSgrammarParser#GTELTE.
    def visitGTELTE(self, ctx:SSgrammarParser.GTELTEContext):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by SSgrammarParser#int.
    def visitInt(self, ctx:SSgrammarParser.IntContext):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by SSgrammarParser#str.
    def visitStr(self, ctx:SSgrammarParser.StrContext):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by SSgrammarParser#FDEX.
    def visitFDEX(self, ctx:SSgrammarParser.FDEXContext):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by SSgrammarParser#GTLT.
    def visitGTLT(self, ctx:SSgrammarParser.GTLTContext):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by SSgrammarParser#Id.
    def visitId(self, ctx:SSgrammarParser.IdContext):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by SSgrammarParser#idIndex.
    def visitIdIndex(self, ctx:SSgrammarParser.IdIndexContext):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by SSgrammarParser#listCont.
    def visitListCont(self, ctx:SSgrammarParser.ListContContext):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by SSgrammarParser#listId.
    def visitListId(self, ctx:SSgrammarParser.ListIdContext):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by SSgrammarParser#lsLitStart.
    def visitLsLitStart(self, ctx:SSgrammarParser.LsLitStartContext):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by SSgrammarParser#listInt.
    def visitListInt(self, ctx:SSgrammarParser.ListIntContext):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by SSgrammarParser#listDec.
    def visitListDec(self, ctx:SSgrammarParser.ListDecContext):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by SSgrammarParser#lsLitCont.
    def visitLsLitCont(self, ctx:SSgrammarParser.LsLitContContext):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by SSgrammarParser#listString.
    def visitListString(self, ctx:SSgrammarParser.ListStringContext):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by SSgrammarParser#string.
    def visitString(self, ctx:SSgrammarParser.StringContext):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by SSgrammarParser#strdec.
    def visitStrdec(self, ctx:SSgrammarParser.StrdecContext):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by SSgrammarParser#strId.
    def visitStrId(self, ctx:SSgrammarParser.StrIdContext):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by SSgrammarParser#repeatStr.
    def visitRepeatStr(self, ctx:SSgrammarParser.RepeatStrContext):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by SSgrammarParser#ConCat.
    def visitConCat(self, ctx:SSgrammarParser.ConCatContext):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by SSgrammarParser#strIndex.
    def visitStrIndex(self, ctx:SSgrammarParser.StrIndexContext):
        return self.visitChildren(ctx)



del SSgrammarParser