# Johnson Lu 109105138

import sys
from antlr4 import *
from antlr4.InputStream import InputStream
from antlr4.error.ErrorListener import ErrorListener
from SSgrammarLexer import SSgrammarLexer
from SSgrammarParser import SSgrammarParser
from MyVisitor import MyVisitor

syntaxErrLines = []


class errorListener( ErrorListener ):


    def __init__(self):
        super(errorListener, self).__init__()

    def syntaxError(self, recognizer, offendingSymbol, line, column, msg, e):
        if line not in syntaxErrLines:
            syntaxErrLines.append(line)

if __name__ == '__main__':
    if len(sys.argv) > 1:
        input_stream = FileStream(sys.argv[1])
    else:
        input_stream = InputStream(sys.stdin.readline())

    lexer = SSgrammarLexer(input_stream)
    #lexer.removeErrorListeners()
    token_stream = CommonTokenStream(lexer)
    parser = SSgrammarParser(token_stream)
    parser._listeners = [errorListener()]
    tree = parser.prog()

    visitor = MyVisitor()
    visitor.setSyntaxError(syntaxErrLines)
    visitor.visit(tree)