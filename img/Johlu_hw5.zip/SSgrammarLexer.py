# Generated from SSgrammar.g4 by ANTLR 4.6
from antlr4 import *
from io import StringIO


def serializedATN():
    with StringIO() as buf:
        buf.write("\3\u0430\ud6d1\u8206\uad2d\u4417\uaef1\u8d80\uaadd\2\37")
        buf.write("\u0097\b\1\4\2\t\2\4\3\t\3\4\4\t\4\4\5\t\5\4\6\t\6\4\7")
        buf.write("\t\7\4\b\t\b\4\t\t\t\4\n\t\n\4\13\t\13\4\f\t\f\4\r\t\r")
        buf.write("\4\16\t\16\4\17\t\17\4\20\t\20\4\21\t\21\4\22\t\22\4\23")
        buf.write("\t\23\4\24\t\24\4\25\t\25\4\26\t\26\4\27\t\27\4\30\t\30")
        buf.write("\4\31\t\31\4\32\t\32\4\33\t\33\4\34\t\34\4\35\t\35\4\36")
        buf.write("\t\36\3\2\3\2\3\3\3\3\3\4\3\4\3\5\3\5\3\6\3\6\3\7\3\7")
        buf.write("\3\b\3\b\3\t\3\t\3\n\3\n\3\13\3\13\3\f\3\f\3\r\3\r\3\r")
        buf.write("\3\16\3\16\3\16\3\17\3\17\3\17\3\20\3\20\3\21\3\21\3\21")
        buf.write("\3\22\3\22\3\22\3\23\3\23\3\23\3\24\3\24\3\25\3\25\3\25")
        buf.write("\3\26\3\26\3\26\3\26\3\27\3\27\3\27\3\27\3\30\3\30\3\30")
        buf.write("\3\31\6\31y\n\31\r\31\16\31z\3\32\6\32~\n\32\r\32\16\32")
        buf.write("\177\3\33\3\33\3\33\3\33\3\34\3\34\7\34\u0088\n\34\f\34")
        buf.write("\16\34\u008b\13\34\3\34\3\34\3\35\5\35\u0090\n\35\3\35")
        buf.write("\3\35\3\36\3\36\3\36\3\36\2\2\37\3\3\5\4\7\5\t\6\13\7")
        buf.write("\r\b\17\t\21\n\23\13\25\f\27\r\31\16\33\17\35\20\37\21")
        buf.write("!\22#\23%\24\'\25)\26+\27-\30/\31\61\32\63\33\65\34\67")
        buf.write("\359\36;\37\3\2\6\4\2C\\c|\3\2\62;\3\2$$\4\2\13\13\"\"")
        buf.write("\u009a\2\3\3\2\2\2\2\5\3\2\2\2\2\7\3\2\2\2\2\t\3\2\2\2")
        buf.write("\2\13\3\2\2\2\2\r\3\2\2\2\2\17\3\2\2\2\2\21\3\2\2\2\2")
        buf.write("\23\3\2\2\2\2\25\3\2\2\2\2\27\3\2\2\2\2\31\3\2\2\2\2\33")
        buf.write("\3\2\2\2\2\35\3\2\2\2\2\37\3\2\2\2\2!\3\2\2\2\2#\3\2\2")
        buf.write("\2\2%\3\2\2\2\2\'\3\2\2\2\2)\3\2\2\2\2+\3\2\2\2\2-\3\2")
        buf.write("\2\2\2/\3\2\2\2\2\61\3\2\2\2\2\63\3\2\2\2\2\65\3\2\2\2")
        buf.write("\2\67\3\2\2\2\29\3\2\2\2\2;\3\2\2\2\3=\3\2\2\2\5?\3\2")
        buf.write("\2\2\7A\3\2\2\2\tC\3\2\2\2\13E\3\2\2\2\rG\3\2\2\2\17I")
        buf.write("\3\2\2\2\21K\3\2\2\2\23M\3\2\2\2\25O\3\2\2\2\27Q\3\2\2")
        buf.write("\2\31S\3\2\2\2\33V\3\2\2\2\35Y\3\2\2\2\37\\\3\2\2\2!^")
        buf.write("\3\2\2\2#a\3\2\2\2%d\3\2\2\2\'g\3\2\2\2)i\3\2\2\2+l\3")
        buf.write("\2\2\2-p\3\2\2\2/t\3\2\2\2\61x\3\2\2\2\63}\3\2\2\2\65")
        buf.write("\u0081\3\2\2\2\67\u0085\3\2\2\29\u008f\3\2\2\2;\u0093")
        buf.write("\3\2\2\2=>\7?\2\2>\4\3\2\2\2?@\7.\2\2@\6\3\2\2\2AB\7]")
        buf.write("\2\2B\b\3\2\2\2CD\7_\2\2D\n\3\2\2\2EF\7*\2\2F\f\3\2\2")
        buf.write("\2GH\7+\2\2H\16\3\2\2\2IJ\7,\2\2J\20\3\2\2\2KL\7\61\2")
        buf.write("\2L\22\3\2\2\2MN\7-\2\2N\24\3\2\2\2OP\7/\2\2P\26\3\2\2")
        buf.write("\2QR\7\'\2\2R\30\3\2\2\2ST\7\61\2\2TU\7\61\2\2U\32\3\2")
        buf.write("\2\2VW\7,\2\2WX\7,\2\2X\34\3\2\2\2YZ\7k\2\2Z[\7p\2\2[")
        buf.write("\36\3\2\2\2\\]\7>\2\2] \3\2\2\2^_\7>\2\2_`\7?\2\2`\"\3")
        buf.write("\2\2\2ab\7?\2\2bc\7?\2\2c$\3\2\2\2de\7>\2\2ef\7@\2\2f")
        buf.write("&\3\2\2\2gh\7@\2\2h(\3\2\2\2ij\7@\2\2jk\7?\2\2k*\3\2\2")
        buf.write("\2lm\7p\2\2mn\7q\2\2no\7v\2\2o,\3\2\2\2pq\7c\2\2qr\7p")
        buf.write("\2\2rs\7f\2\2s.\3\2\2\2tu\7q\2\2uv\7t\2\2v\60\3\2\2\2")
        buf.write("wy\t\2\2\2xw\3\2\2\2yz\3\2\2\2zx\3\2\2\2z{\3\2\2\2{\62")
        buf.write("\3\2\2\2|~\t\3\2\2}|\3\2\2\2~\177\3\2\2\2\177}\3\2\2\2")
        buf.write("\177\u0080\3\2\2\2\u0080\64\3\2\2\2\u0081\u0082\5\63\32")
        buf.write("\2\u0082\u0083\7\60\2\2\u0083\u0084\5\63\32\2\u0084\66")
        buf.write("\3\2\2\2\u0085\u0089\7$\2\2\u0086\u0088\n\4\2\2\u0087")
        buf.write("\u0086\3\2\2\2\u0088\u008b\3\2\2\2\u0089\u0087\3\2\2\2")
        buf.write("\u0089\u008a\3\2\2\2\u008a\u008c\3\2\2\2\u008b\u0089\3")
        buf.write("\2\2\2\u008c\u008d\7$\2\2\u008d8\3\2\2\2\u008e\u0090\7")
        buf.write("\17\2\2\u008f\u008e\3\2\2\2\u008f\u0090\3\2\2\2\u0090")
        buf.write("\u0091\3\2\2\2\u0091\u0092\7\f\2\2\u0092:\3\2\2\2\u0093")
        buf.write("\u0094\t\5\2\2\u0094\u0095\3\2\2\2\u0095\u0096\b\36\2")
        buf.write("\2\u0096<\3\2\2\2\7\2z\177\u0089\u008f\3\b\2\2")
        return buf.getvalue()


class SSgrammarLexer(Lexer):

    atn = ATNDeserializer().deserialize(serializedATN())

    decisionsToDFA = [ DFA(ds, i) for i, ds in enumerate(atn.decisionToState) ]


    T__0 = 1
    T__1 = 2
    T__2 = 3
    T__3 = 4
    T__4 = 5
    T__5 = 6
    MUL = 7
    DIV = 8
    ADD = 9
    SUB = 10
    MOD = 11
    FDIV = 12
    EXPO = 13
    IN = 14
    LT = 15
    LTE = 16
    EQT = 17
    NEQT = 18
    GT = 19
    GTE = 20
    NOT = 21
    AND = 22
    OR = 23
    ID = 24
    INT = 25
    DEC = 26
    STRING = 27
    NEWLINE = 28
    WS = 29

    modeNames = [ "DEFAULT_MODE" ]

    literalNames = [ "<INVALID>",
            "'='", "','", "'['", "']'", "'('", "')'", "'*'", "'/'", "'+'", 
            "'-'", "'%'", "'//'", "'**'", "'in'", "'<'", "'<='", "'=='", 
            "'<>'", "'>'", "'>='", "'not'", "'and'", "'or'" ]

    symbolicNames = [ "<INVALID>",
            "MUL", "DIV", "ADD", "SUB", "MOD", "FDIV", "EXPO", "IN", "LT", 
            "LTE", "EQT", "NEQT", "GT", "GTE", "NOT", "AND", "OR", "ID", 
            "INT", "DEC", "STRING", "NEWLINE", "WS" ]

    ruleNames = [ "T__0", "T__1", "T__2", "T__3", "T__4", "T__5", "MUL", 
                  "DIV", "ADD", "SUB", "MOD", "FDIV", "EXPO", "IN", "LT", 
                  "LTE", "EQT", "NEQT", "GT", "GTE", "NOT", "AND", "OR", 
                  "ID", "INT", "DEC", "STRING", "NEWLINE", "WS" ]

    grammarFileName = "SSgrammar.g4"

    def __init__(self, input=None):
        super().__init__(input)
        self.checkVersion("4.6")
        self._interp = LexerATNSimulator(self, self.atn, self.decisionsToDFA, PredictionContextCache())
        self._actions = None
        self._predicates = None


