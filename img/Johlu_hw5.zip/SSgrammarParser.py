# Generated from SSgrammar.g4 by ANTLR 4.6
# encoding: utf-8
from antlr4 import *
from io import StringIO

def serializedATN():
    with StringIO() as buf:
        buf.write("\3\u0430\ud6d1\u8206\uad2d\u4417\uaef1\u8d80\uaadd\3\37")
        buf.write("\u0091\4\2\t\2\4\3\t\3\4\4\t\4\4\5\t\5\4\6\t\6\4\7\t\7")
        buf.write("\3\2\6\2\20\n\2\r\2\16\2\21\3\3\3\3\3\3\3\3\3\3\3\3\3")
        buf.write("\3\3\3\3\3\3\3\3\3\3\3\3\3\3\3\3\3\3\3\3\3\3\3\3\3\3\3")
        buf.write("\3\3\5\3)\n\3\3\4\3\4\5\4-\n\4\3\5\3\5\3\5\3\5\3\5\3\5")
        buf.write("\3\5\3\5\3\5\3\5\3\5\3\5\3\5\3\5\3\5\3\5\3\5\3\5\5\5A")
        buf.write("\n\5\3\5\3\5\3\5\3\5\3\5\3\5\3\5\3\5\3\5\3\5\3\5\3\5\3")
        buf.write("\5\3\5\3\5\3\5\3\5\3\5\3\5\3\5\3\5\3\5\3\5\3\5\3\5\3\5")
        buf.write("\3\5\3\5\3\5\3\5\3\5\3\5\7\5c\n\5\f\5\16\5f\13\5\3\6\3")
        buf.write("\6\3\6\3\6\3\6\3\6\3\6\3\6\3\6\5\6q\n\6\3\6\3\6\3\6\7")
        buf.write("\6v\n\6\f\6\16\6y\13\6\3\7\3\7\3\7\3\7\5\7\177\n\7\3\7")
        buf.write("\3\7\3\7\3\7\3\7\3\7\3\7\3\7\3\7\3\7\3\7\7\7\u008c\n\7")
        buf.write("\f\7\16\7\u008f\13\7\3\7\2\5\b\n\f\b\2\4\6\b\n\f\2\t\3")
        buf.write("\2\t\n\3\2\16\17\3\2\13\f\4\2\21\21\25\25\4\2\22\22\26")
        buf.write("\26\3\2\23\24\3\2\30\31\u00aa\2\17\3\2\2\2\4(\3\2\2\2")
        buf.write("\6,\3\2\2\2\b@\3\2\2\2\np\3\2\2\2\f~\3\2\2\2\16\20\5\4")
        buf.write("\3\2\17\16\3\2\2\2\20\21\3\2\2\2\21\17\3\2\2\2\21\22\3")
        buf.write("\2\2\2\22\3\3\2\2\2\23\24\5\f\7\2\24\25\5\6\4\2\25)\3")
        buf.write("\2\2\2\26\27\5\b\5\2\27\30\5\6\4\2\30)\3\2\2\2\31\32\7")
        buf.write("\32\2\2\32\33\7\3\2\2\33\34\5\b\5\2\34\35\5\6\4\2\35)")
        buf.write("\3\2\2\2\36\37\7\32\2\2\37 \7\3\2\2 !\5\f\7\2!\"\5\6\4")
        buf.write("\2\")\3\2\2\2#$\7\32\2\2$%\7\3\2\2%&\5\n\6\2&\'\5\6\4")
        buf.write("\2\')\3\2\2\2(\23\3\2\2\2(\26\3\2\2\2(\31\3\2\2\2(\36")
        buf.write("\3\2\2\2(#\3\2\2\2)\5\3\2\2\2*-\7\36\2\2+-\7\2\2\3,*\3")
        buf.write("\2\2\2,+\3\2\2\2-\7\3\2\2\2./\b\5\1\2/\60\7\5\2\2\60\61")
        buf.write("\5\b\5\2\61\62\7\6\2\2\62\63\7\5\2\2\63\64\5\b\5\2\64")
        buf.write("\65\7\6\2\2\65A\3\2\2\2\66\67\7\27\2\2\67A\5\b\5\b8A\7")
        buf.write("\34\2\29A\7\33\2\2:A\7\32\2\2;A\7\35\2\2<=\7\7\2\2=>\5")
        buf.write("\b\5\2>?\7\b\2\2?A\3\2\2\2@.\3\2\2\2@\66\3\2\2\2@8\3\2")
        buf.write("\2\2@9\3\2\2\2@:\3\2\2\2@;\3\2\2\2@<\3\2\2\2Ad\3\2\2\2")
        buf.write("BC\f\23\2\2CD\t\2\2\2Dc\5\b\5\24EF\f\22\2\2FG\t\3\2\2")
        buf.write("Gc\5\b\5\23HI\f\21\2\2IJ\7\r\2\2Jc\5\b\5\22KL\f\20\2\2")
        buf.write("LM\t\4\2\2Mc\5\b\5\21NO\f\17\2\2OP\t\5\2\2Pc\5\b\5\20")
        buf.write("QR\f\16\2\2RS\t\6\2\2Sc\5\b\5\17TU\f\r\2\2UV\t\7\2\2V")
        buf.write("c\5\b\5\16WX\f\f\2\2XY\t\b\2\2Yc\5\b\5\rZ[\f\13\2\2[\\")
        buf.write("\7\4\2\2\\c\5\b\5\f]^\f\t\2\2^_\7\5\2\2_`\5\b\5\2`a\7")
        buf.write("\6\2\2ac\3\2\2\2bB\3\2\2\2bE\3\2\2\2bH\3\2\2\2bK\3\2\2")
        buf.write("\2bN\3\2\2\2bQ\3\2\2\2bT\3\2\2\2bW\3\2\2\2bZ\3\2\2\2b")
        buf.write("]\3\2\2\2cf\3\2\2\2db\3\2\2\2de\3\2\2\2e\t\3\2\2\2fd\3")
        buf.write("\2\2\2gh\b\6\1\2hi\7\5\2\2ij\5\n\6\2jk\7\6\2\2kq\3\2\2")
        buf.write("\2lq\7\33\2\2mq\7\32\2\2nq\7\34\2\2oq\5\f\7\2pg\3\2\2")
        buf.write("\2pl\3\2\2\2pm\3\2\2\2pn\3\2\2\2po\3\2\2\2qw\3\2\2\2r")
        buf.write("s\f\7\2\2st\7\4\2\2tv\5\n\6\bur\3\2\2\2vy\3\2\2\2wu\3")
        buf.write("\2\2\2wx\3\2\2\2x\13\3\2\2\2yw\3\2\2\2z{\b\7\1\2{\177")
        buf.write("\7\35\2\2|\177\7\32\2\2}\177\7\34\2\2~z\3\2\2\2~|\3\2")
        buf.write("\2\2~}\3\2\2\2\177\u008d\3\2\2\2\u0080\u0081\f\b\2\2\u0081")
        buf.write("\u0082\7\t\2\2\u0082\u008c\5\f\7\t\u0083\u0084\f\7\2\2")
        buf.write("\u0084\u0085\7\13\2\2\u0085\u008c\5\f\7\b\u0086\u0087")
        buf.write("\f\6\2\2\u0087\u0088\7\5\2\2\u0088\u0089\5\b\5\2\u0089")
        buf.write("\u008a\7\6\2\2\u008a\u008c\3\2\2\2\u008b\u0080\3\2\2\2")
        buf.write("\u008b\u0083\3\2\2\2\u008b\u0086\3\2\2\2\u008c\u008f\3")
        buf.write("\2\2\2\u008d\u008b\3\2\2\2\u008d\u008e\3\2\2\2\u008e\r")
        buf.write("\3\2\2\2\u008f\u008d\3\2\2\2\r\21(,@bdpw~\u008b\u008d")
        return buf.getvalue()


class SSgrammarParser ( Parser ):

    grammarFileName = "SSgrammar.g4"

    atn = ATNDeserializer().deserialize(serializedATN())

    decisionsToDFA = [ DFA(ds, i) for i, ds in enumerate(atn.decisionToState) ]

    sharedContextCache = PredictionContextCache()

    literalNames = [ "<INVALID>", "'='", "','", "'['", "']'", "'('", "')'", 
                     "'*'", "'/'", "'+'", "'-'", "'%'", "'//'", "'**'", 
                     "'in'", "'<'", "'<='", "'=='", "'<>'", "'>'", "'>='", 
                     "'not'", "'and'", "'or'" ]

    symbolicNames = [ "<INVALID>", "<INVALID>", "<INVALID>", "<INVALID>", 
                      "<INVALID>", "<INVALID>", "<INVALID>", "MUL", "DIV", 
                      "ADD", "SUB", "MOD", "FDIV", "EXPO", "IN", "LT", "LTE", 
                      "EQT", "NEQT", "GT", "GTE", "NOT", "AND", "OR", "ID", 
                      "INT", "DEC", "STRING", "NEWLINE", "WS" ]

    RULE_prog = 0
    RULE_stat = 1
    RULE_end = 2
    RULE_expr = 3
    RULE_listLit = 4
    RULE_strLit = 5

    ruleNames =  [ "prog", "stat", "end", "expr", "listLit", "strLit" ]

    EOF = Token.EOF
    T__0=1
    T__1=2
    T__2=3
    T__3=4
    T__4=5
    T__5=6
    MUL=7
    DIV=8
    ADD=9
    SUB=10
    MOD=11
    FDIV=12
    EXPO=13
    IN=14
    LT=15
    LTE=16
    EQT=17
    NEQT=18
    GT=19
    GTE=20
    NOT=21
    AND=22
    OR=23
    ID=24
    INT=25
    DEC=26
    STRING=27
    NEWLINE=28
    WS=29

    def __init__(self, input:TokenStream):
        super().__init__(input)
        self.checkVersion("4.6")
        self._interp = ParserATNSimulator(self, self.atn, self.decisionsToDFA, self.sharedContextCache)
        self._predicates = None



    class ProgContext(ParserRuleContext):

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def stat(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(SSgrammarParser.StatContext)
            else:
                return self.getTypedRuleContext(SSgrammarParser.StatContext,i)


        def getRuleIndex(self):
            return SSgrammarParser.RULE_prog

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitProg" ):
                return visitor.visitProg(self)
            else:
                return visitor.visitChildren(self)




    def prog(self):

        localctx = SSgrammarParser.ProgContext(self, self._ctx, self.state)
        self.enterRule(localctx, 0, self.RULE_prog)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 13 
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            while True:
                self.state = 12
                self.stat()
                self.state = 15 
                self._errHandler.sync(self)
                _la = self._input.LA(1)
                if not ((((_la) & ~0x3f) == 0 and ((1 << _la) & ((1 << SSgrammarParser.T__2) | (1 << SSgrammarParser.T__4) | (1 << SSgrammarParser.NOT) | (1 << SSgrammarParser.ID) | (1 << SSgrammarParser.INT) | (1 << SSgrammarParser.DEC) | (1 << SSgrammarParser.STRING))) != 0)):
                    break

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx

    class StatContext(ParserRuleContext):

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser


        def getRuleIndex(self):
            return SSgrammarParser.RULE_stat

     
        def copyFrom(self, ctx:ParserRuleContext):
            super().copyFrom(ctx)



    class AssignListContext(StatContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a SSgrammarParser.StatContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def ID(self):
            return self.getToken(SSgrammarParser.ID, 0)
        def listLit(self):
            return self.getTypedRuleContext(SSgrammarParser.ListLitContext,0)

        def end(self):
            return self.getTypedRuleContext(SSgrammarParser.EndContext,0)


        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitAssignList" ):
                return visitor.visitAssignList(self)
            else:
                return visitor.visitChildren(self)


    class PrintStrContext(StatContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a SSgrammarParser.StatContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def strLit(self):
            return self.getTypedRuleContext(SSgrammarParser.StrLitContext,0)

        def end(self):
            return self.getTypedRuleContext(SSgrammarParser.EndContext,0)


        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitPrintStr" ):
                return visitor.visitPrintStr(self)
            else:
                return visitor.visitChildren(self)


    class PrintExprContext(StatContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a SSgrammarParser.StatContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def expr(self):
            return self.getTypedRuleContext(SSgrammarParser.ExprContext,0)

        def end(self):
            return self.getTypedRuleContext(SSgrammarParser.EndContext,0)


        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitPrintExpr" ):
                return visitor.visitPrintExpr(self)
            else:
                return visitor.visitChildren(self)


    class AssignContext(StatContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a SSgrammarParser.StatContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def ID(self):
            return self.getToken(SSgrammarParser.ID, 0)
        def expr(self):
            return self.getTypedRuleContext(SSgrammarParser.ExprContext,0)

        def end(self):
            return self.getTypedRuleContext(SSgrammarParser.EndContext,0)


        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitAssign" ):
                return visitor.visitAssign(self)
            else:
                return visitor.visitChildren(self)


    class AssignStrContext(StatContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a SSgrammarParser.StatContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def ID(self):
            return self.getToken(SSgrammarParser.ID, 0)
        def strLit(self):
            return self.getTypedRuleContext(SSgrammarParser.StrLitContext,0)

        def end(self):
            return self.getTypedRuleContext(SSgrammarParser.EndContext,0)


        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitAssignStr" ):
                return visitor.visitAssignStr(self)
            else:
                return visitor.visitChildren(self)



    def stat(self):

        localctx = SSgrammarParser.StatContext(self, self._ctx, self.state)
        self.enterRule(localctx, 2, self.RULE_stat)
        try:
            self.state = 38
            self._errHandler.sync(self)
            la_ = self._interp.adaptivePredict(self._input,1,self._ctx)
            if la_ == 1:
                localctx = SSgrammarParser.PrintStrContext(self, localctx)
                self.enterOuterAlt(localctx, 1)
                self.state = 17
                self.strLit(0)
                self.state = 18
                self.end()
                pass

            elif la_ == 2:
                localctx = SSgrammarParser.PrintExprContext(self, localctx)
                self.enterOuterAlt(localctx, 2)
                self.state = 20
                self.expr(0)
                self.state = 21
                self.end()
                pass

            elif la_ == 3:
                localctx = SSgrammarParser.AssignContext(self, localctx)
                self.enterOuterAlt(localctx, 3)
                self.state = 23
                self.match(SSgrammarParser.ID)
                self.state = 24
                self.match(SSgrammarParser.T__0)
                self.state = 25
                self.expr(0)
                self.state = 26
                self.end()
                pass

            elif la_ == 4:
                localctx = SSgrammarParser.AssignStrContext(self, localctx)
                self.enterOuterAlt(localctx, 4)
                self.state = 28
                self.match(SSgrammarParser.ID)
                self.state = 29
                self.match(SSgrammarParser.T__0)
                self.state = 30
                self.strLit(0)
                self.state = 31
                self.end()
                pass

            elif la_ == 5:
                localctx = SSgrammarParser.AssignListContext(self, localctx)
                self.enterOuterAlt(localctx, 5)
                self.state = 33
                self.match(SSgrammarParser.ID)
                self.state = 34
                self.match(SSgrammarParser.T__0)
                self.state = 35
                self.listLit(0)
                self.state = 36
                self.end()
                pass


        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx

    class EndContext(ParserRuleContext):

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser


        def getRuleIndex(self):
            return SSgrammarParser.RULE_end

     
        def copyFrom(self, ctx:ParserRuleContext):
            super().copyFrom(ctx)



    class NewLineContext(EndContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a SSgrammarParser.EndContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def NEWLINE(self):
            return self.getToken(SSgrammarParser.NEWLINE, 0)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitNewLine" ):
                return visitor.visitNewLine(self)
            else:
                return visitor.visitChildren(self)


    class EOFContext(EndContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a SSgrammarParser.EndContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def EOF(self):
            return self.getToken(SSgrammarParser.EOF, 0)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitEOF" ):
                return visitor.visitEOF(self)
            else:
                return visitor.visitChildren(self)



    def end(self):

        localctx = SSgrammarParser.EndContext(self, self._ctx, self.state)
        self.enterRule(localctx, 4, self.RULE_end)
        try:
            self.state = 42
            self._errHandler.sync(self)
            token = self._input.LA(1)
            if token in [SSgrammarParser.NEWLINE]:
                localctx = SSgrammarParser.NewLineContext(self, localctx)
                self.enterOuterAlt(localctx, 1)
                self.state = 40
                self.match(SSgrammarParser.NEWLINE)
                pass
            elif token in [SSgrammarParser.EOF]:
                localctx = SSgrammarParser.EOFContext(self, localctx)
                self.enterOuterAlt(localctx, 2)
                self.state = 41
                self.match(SSgrammarParser.EOF)
                pass
            else:
                raise NoViableAltException(self)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx

    class ExprContext(ParserRuleContext):

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser


        def getRuleIndex(self):
            return SSgrammarParser.RULE_expr

     
        def copyFrom(self, ctx:ParserRuleContext):
            super().copyFrom(ctx)


    class MODOPContext(ExprContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a SSgrammarParser.ExprContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def expr(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(SSgrammarParser.ExprContext)
            else:
                return self.getTypedRuleContext(SSgrammarParser.ExprContext,i)

        def MOD(self):
            return self.getToken(SSgrammarParser.MOD, 0)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitMODOP" ):
                return visitor.visitMODOP(self)
            else:
                return visitor.visitChildren(self)


    class ParensContext(ExprContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a SSgrammarParser.ExprContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def expr(self):
            return self.getTypedRuleContext(SSgrammarParser.ExprContext,0)


        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitParens" ):
                return visitor.visitParens(self)
            else:
                return visitor.visitChildren(self)


    class ANDORContext(ExprContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a SSgrammarParser.ExprContext
            super().__init__(parser)
            self.op = None # Token
            self.copyFrom(ctx)

        def expr(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(SSgrammarParser.ExprContext)
            else:
                return self.getTypedRuleContext(SSgrammarParser.ExprContext,i)


        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitANDOR" ):
                return visitor.visitANDOR(self)
            else:
                return visitor.visitChildren(self)


    class DecContext(ExprContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a SSgrammarParser.ExprContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def DEC(self):
            return self.getToken(SSgrammarParser.DEC, 0)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitDec" ):
                return visitor.visitDec(self)
            else:
                return visitor.visitChildren(self)


    class EQNEContext(ExprContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a SSgrammarParser.ExprContext
            super().__init__(parser)
            self.op = None # Token
            self.copyFrom(ctx)

        def expr(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(SSgrammarParser.ExprContext)
            else:
                return self.getTypedRuleContext(SSgrammarParser.ExprContext,i)


        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitEQNE" ):
                return visitor.visitEQNE(self)
            else:
                return visitor.visitChildren(self)


    class ListStartContext(ExprContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a SSgrammarParser.ExprContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def expr(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(SSgrammarParser.ExprContext)
            else:
                return self.getTypedRuleContext(SSgrammarParser.ExprContext,i)


        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitListStart" ):
                return visitor.visitListStart(self)
            else:
                return visitor.visitChildren(self)


    class MulDivContext(ExprContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a SSgrammarParser.ExprContext
            super().__init__(parser)
            self.op = None # Token
            self.copyFrom(ctx)

        def expr(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(SSgrammarParser.ExprContext)
            else:
                return self.getTypedRuleContext(SSgrammarParser.ExprContext,i)


        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitMulDiv" ):
                return visitor.visitMulDiv(self)
            else:
                return visitor.visitChildren(self)


    class AddSubContext(ExprContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a SSgrammarParser.ExprContext
            super().__init__(parser)
            self.op = None # Token
            self.copyFrom(ctx)

        def expr(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(SSgrammarParser.ExprContext)
            else:
                return self.getTypedRuleContext(SSgrammarParser.ExprContext,i)


        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitAddSub" ):
                return visitor.visitAddSub(self)
            else:
                return visitor.visitChildren(self)


    class NotValContext(ExprContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a SSgrammarParser.ExprContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def NOT(self):
            return self.getToken(SSgrammarParser.NOT, 0)
        def expr(self):
            return self.getTypedRuleContext(SSgrammarParser.ExprContext,0)


        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitNotVal" ):
                return visitor.visitNotVal(self)
            else:
                return visitor.visitChildren(self)


    class GTELTEContext(ExprContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a SSgrammarParser.ExprContext
            super().__init__(parser)
            self.op = None # Token
            self.copyFrom(ctx)

        def expr(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(SSgrammarParser.ExprContext)
            else:
                return self.getTypedRuleContext(SSgrammarParser.ExprContext,i)


        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitGTELTE" ):
                return visitor.visitGTELTE(self)
            else:
                return visitor.visitChildren(self)


    class IntContext(ExprContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a SSgrammarParser.ExprContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def INT(self):
            return self.getToken(SSgrammarParser.INT, 0)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitInt" ):
                return visitor.visitInt(self)
            else:
                return visitor.visitChildren(self)


    class StrContext(ExprContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a SSgrammarParser.ExprContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def STRING(self):
            return self.getToken(SSgrammarParser.STRING, 0)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitStr" ):
                return visitor.visitStr(self)
            else:
                return visitor.visitChildren(self)


    class FDEXContext(ExprContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a SSgrammarParser.ExprContext
            super().__init__(parser)
            self.op = None # Token
            self.copyFrom(ctx)

        def expr(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(SSgrammarParser.ExprContext)
            else:
                return self.getTypedRuleContext(SSgrammarParser.ExprContext,i)


        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitFDEX" ):
                return visitor.visitFDEX(self)
            else:
                return visitor.visitChildren(self)


    class GTLTContext(ExprContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a SSgrammarParser.ExprContext
            super().__init__(parser)
            self.op = None # Token
            self.copyFrom(ctx)

        def expr(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(SSgrammarParser.ExprContext)
            else:
                return self.getTypedRuleContext(SSgrammarParser.ExprContext,i)


        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitGTLT" ):
                return visitor.visitGTLT(self)
            else:
                return visitor.visitChildren(self)


    class IdContext(ExprContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a SSgrammarParser.ExprContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def ID(self):
            return self.getToken(SSgrammarParser.ID, 0)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitId" ):
                return visitor.visitId(self)
            else:
                return visitor.visitChildren(self)


    class IdIndexContext(ExprContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a SSgrammarParser.ExprContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def expr(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(SSgrammarParser.ExprContext)
            else:
                return self.getTypedRuleContext(SSgrammarParser.ExprContext,i)


        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitIdIndex" ):
                return visitor.visitIdIndex(self)
            else:
                return visitor.visitChildren(self)


    class ListContContext(ExprContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a SSgrammarParser.ExprContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def expr(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(SSgrammarParser.ExprContext)
            else:
                return self.getTypedRuleContext(SSgrammarParser.ExprContext,i)


        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitListCont" ):
                return visitor.visitListCont(self)
            else:
                return visitor.visitChildren(self)



    def expr(self, _p:int=0):
        _parentctx = self._ctx
        _parentState = self.state
        localctx = SSgrammarParser.ExprContext(self, self._ctx, _parentState)
        _prevctx = localctx
        _startState = 6
        self.enterRecursionRule(localctx, 6, self.RULE_expr, _p)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 62
            self._errHandler.sync(self)
            token = self._input.LA(1)
            if token in [SSgrammarParser.T__2]:
                localctx = SSgrammarParser.ListStartContext(self, localctx)
                self._ctx = localctx
                _prevctx = localctx

                self.state = 45
                self.match(SSgrammarParser.T__2)
                self.state = 46
                self.expr(0)
                self.state = 47
                self.match(SSgrammarParser.T__3)
                self.state = 48
                self.match(SSgrammarParser.T__2)
                self.state = 49
                self.expr(0)
                self.state = 50
                self.match(SSgrammarParser.T__3)
                pass
            elif token in [SSgrammarParser.NOT]:
                localctx = SSgrammarParser.NotValContext(self, localctx)
                self._ctx = localctx
                _prevctx = localctx
                self.state = 52
                self.match(SSgrammarParser.NOT)
                self.state = 53
                self.expr(6)
                pass
            elif token in [SSgrammarParser.DEC]:
                localctx = SSgrammarParser.DecContext(self, localctx)
                self._ctx = localctx
                _prevctx = localctx
                self.state = 54
                self.match(SSgrammarParser.DEC)
                pass
            elif token in [SSgrammarParser.INT]:
                localctx = SSgrammarParser.IntContext(self, localctx)
                self._ctx = localctx
                _prevctx = localctx
                self.state = 55
                self.match(SSgrammarParser.INT)
                pass
            elif token in [SSgrammarParser.ID]:
                localctx = SSgrammarParser.IdContext(self, localctx)
                self._ctx = localctx
                _prevctx = localctx
                self.state = 56
                self.match(SSgrammarParser.ID)
                pass
            elif token in [SSgrammarParser.STRING]:
                localctx = SSgrammarParser.StrContext(self, localctx)
                self._ctx = localctx
                _prevctx = localctx
                self.state = 57
                self.match(SSgrammarParser.STRING)
                pass
            elif token in [SSgrammarParser.T__4]:
                localctx = SSgrammarParser.ParensContext(self, localctx)
                self._ctx = localctx
                _prevctx = localctx
                self.state = 58
                self.match(SSgrammarParser.T__4)
                self.state = 59
                self.expr(0)
                self.state = 60
                self.match(SSgrammarParser.T__5)
                pass
            else:
                raise NoViableAltException(self)

            self._ctx.stop = self._input.LT(-1)
            self.state = 98
            self._errHandler.sync(self)
            _alt = self._interp.adaptivePredict(self._input,5,self._ctx)
            while _alt!=2 and _alt!=ATN.INVALID_ALT_NUMBER:
                if _alt==1:
                    if self._parseListeners is not None:
                        self.triggerExitRuleEvent()
                    _prevctx = localctx
                    self.state = 96
                    self._errHandler.sync(self)
                    la_ = self._interp.adaptivePredict(self._input,4,self._ctx)
                    if la_ == 1:
                        localctx = SSgrammarParser.MulDivContext(self, SSgrammarParser.ExprContext(self, _parentctx, _parentState))
                        self.pushNewRecursionContext(localctx, _startState, self.RULE_expr)
                        self.state = 64
                        if not self.precpred(self._ctx, 17):
                            from antlr4.error.Errors import FailedPredicateException
                            raise FailedPredicateException(self, "self.precpred(self._ctx, 17)")
                        self.state = 65
                        localctx.op = self._input.LT(1)
                        _la = self._input.LA(1)
                        if not(_la==SSgrammarParser.MUL or _la==SSgrammarParser.DIV):
                            localctx.op = self._errHandler.recoverInline(self)
                        else:
                            self._errHandler.reportMatch(self)
                            self.consume()
                        self.state = 66
                        self.expr(18)
                        pass

                    elif la_ == 2:
                        localctx = SSgrammarParser.FDEXContext(self, SSgrammarParser.ExprContext(self, _parentctx, _parentState))
                        self.pushNewRecursionContext(localctx, _startState, self.RULE_expr)
                        self.state = 67
                        if not self.precpred(self._ctx, 16):
                            from antlr4.error.Errors import FailedPredicateException
                            raise FailedPredicateException(self, "self.precpred(self._ctx, 16)")
                        self.state = 68
                        localctx.op = self._input.LT(1)
                        _la = self._input.LA(1)
                        if not(_la==SSgrammarParser.FDIV or _la==SSgrammarParser.EXPO):
                            localctx.op = self._errHandler.recoverInline(self)
                        else:
                            self._errHandler.reportMatch(self)
                            self.consume()
                        self.state = 69
                        self.expr(17)
                        pass

                    elif la_ == 3:
                        localctx = SSgrammarParser.MODOPContext(self, SSgrammarParser.ExprContext(self, _parentctx, _parentState))
                        self.pushNewRecursionContext(localctx, _startState, self.RULE_expr)
                        self.state = 70
                        if not self.precpred(self._ctx, 15):
                            from antlr4.error.Errors import FailedPredicateException
                            raise FailedPredicateException(self, "self.precpred(self._ctx, 15)")
                        self.state = 71
                        self.match(SSgrammarParser.MOD)
                        self.state = 72
                        self.expr(16)
                        pass

                    elif la_ == 4:
                        localctx = SSgrammarParser.AddSubContext(self, SSgrammarParser.ExprContext(self, _parentctx, _parentState))
                        self.pushNewRecursionContext(localctx, _startState, self.RULE_expr)
                        self.state = 73
                        if not self.precpred(self._ctx, 14):
                            from antlr4.error.Errors import FailedPredicateException
                            raise FailedPredicateException(self, "self.precpred(self._ctx, 14)")
                        self.state = 74
                        localctx.op = self._input.LT(1)
                        _la = self._input.LA(1)
                        if not(_la==SSgrammarParser.ADD or _la==SSgrammarParser.SUB):
                            localctx.op = self._errHandler.recoverInline(self)
                        else:
                            self._errHandler.reportMatch(self)
                            self.consume()
                        self.state = 75
                        self.expr(15)
                        pass

                    elif la_ == 5:
                        localctx = SSgrammarParser.GTLTContext(self, SSgrammarParser.ExprContext(self, _parentctx, _parentState))
                        self.pushNewRecursionContext(localctx, _startState, self.RULE_expr)
                        self.state = 76
                        if not self.precpred(self._ctx, 13):
                            from antlr4.error.Errors import FailedPredicateException
                            raise FailedPredicateException(self, "self.precpred(self._ctx, 13)")
                        self.state = 77
                        localctx.op = self._input.LT(1)
                        _la = self._input.LA(1)
                        if not(_la==SSgrammarParser.LT or _la==SSgrammarParser.GT):
                            localctx.op = self._errHandler.recoverInline(self)
                        else:
                            self._errHandler.reportMatch(self)
                            self.consume()
                        self.state = 78
                        self.expr(14)
                        pass

                    elif la_ == 6:
                        localctx = SSgrammarParser.GTELTEContext(self, SSgrammarParser.ExprContext(self, _parentctx, _parentState))
                        self.pushNewRecursionContext(localctx, _startState, self.RULE_expr)
                        self.state = 79
                        if not self.precpred(self._ctx, 12):
                            from antlr4.error.Errors import FailedPredicateException
                            raise FailedPredicateException(self, "self.precpred(self._ctx, 12)")
                        self.state = 80
                        localctx.op = self._input.LT(1)
                        _la = self._input.LA(1)
                        if not(_la==SSgrammarParser.LTE or _la==SSgrammarParser.GTE):
                            localctx.op = self._errHandler.recoverInline(self)
                        else:
                            self._errHandler.reportMatch(self)
                            self.consume()
                        self.state = 81
                        self.expr(13)
                        pass

                    elif la_ == 7:
                        localctx = SSgrammarParser.EQNEContext(self, SSgrammarParser.ExprContext(self, _parentctx, _parentState))
                        self.pushNewRecursionContext(localctx, _startState, self.RULE_expr)
                        self.state = 82
                        if not self.precpred(self._ctx, 11):
                            from antlr4.error.Errors import FailedPredicateException
                            raise FailedPredicateException(self, "self.precpred(self._ctx, 11)")
                        self.state = 83
                        localctx.op = self._input.LT(1)
                        _la = self._input.LA(1)
                        if not(_la==SSgrammarParser.EQT or _la==SSgrammarParser.NEQT):
                            localctx.op = self._errHandler.recoverInline(self)
                        else:
                            self._errHandler.reportMatch(self)
                            self.consume()
                        self.state = 84
                        self.expr(12)
                        pass

                    elif la_ == 8:
                        localctx = SSgrammarParser.ANDORContext(self, SSgrammarParser.ExprContext(self, _parentctx, _parentState))
                        self.pushNewRecursionContext(localctx, _startState, self.RULE_expr)
                        self.state = 85
                        if not self.precpred(self._ctx, 10):
                            from antlr4.error.Errors import FailedPredicateException
                            raise FailedPredicateException(self, "self.precpred(self._ctx, 10)")
                        self.state = 86
                        localctx.op = self._input.LT(1)
                        _la = self._input.LA(1)
                        if not(_la==SSgrammarParser.AND or _la==SSgrammarParser.OR):
                            localctx.op = self._errHandler.recoverInline(self)
                        else:
                            self._errHandler.reportMatch(self)
                            self.consume()
                        self.state = 87
                        self.expr(11)
                        pass

                    elif la_ == 9:
                        localctx = SSgrammarParser.ListContContext(self, SSgrammarParser.ExprContext(self, _parentctx, _parentState))
                        self.pushNewRecursionContext(localctx, _startState, self.RULE_expr)
                        self.state = 88
                        if not self.precpred(self._ctx, 9):
                            from antlr4.error.Errors import FailedPredicateException
                            raise FailedPredicateException(self, "self.precpred(self._ctx, 9)")
                        self.state = 89
                        self.match(SSgrammarParser.T__1)
                        self.state = 90
                        self.expr(10)
                        pass

                    elif la_ == 10:
                        localctx = SSgrammarParser.IdIndexContext(self, SSgrammarParser.ExprContext(self, _parentctx, _parentState))
                        self.pushNewRecursionContext(localctx, _startState, self.RULE_expr)
                        self.state = 91
                        if not self.precpred(self._ctx, 7):
                            from antlr4.error.Errors import FailedPredicateException
                            raise FailedPredicateException(self, "self.precpred(self._ctx, 7)")
                        self.state = 92
                        self.match(SSgrammarParser.T__2)
                        self.state = 93
                        self.expr(0)
                        self.state = 94
                        self.match(SSgrammarParser.T__3)
                        pass

             
                self.state = 100
                self._errHandler.sync(self)
                _alt = self._interp.adaptivePredict(self._input,5,self._ctx)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.unrollRecursionContexts(_parentctx)
        return localctx

    class ListLitContext(ParserRuleContext):

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser


        def getRuleIndex(self):
            return SSgrammarParser.RULE_listLit

     
        def copyFrom(self, ctx:ParserRuleContext):
            super().copyFrom(ctx)


    class ListIdContext(ListLitContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a SSgrammarParser.ListLitContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def ID(self):
            return self.getToken(SSgrammarParser.ID, 0)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitListId" ):
                return visitor.visitListId(self)
            else:
                return visitor.visitChildren(self)


    class LsLitStartContext(ListLitContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a SSgrammarParser.ListLitContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def listLit(self):
            return self.getTypedRuleContext(SSgrammarParser.ListLitContext,0)


        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitLsLitStart" ):
                return visitor.visitLsLitStart(self)
            else:
                return visitor.visitChildren(self)


    class ListIntContext(ListLitContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a SSgrammarParser.ListLitContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def INT(self):
            return self.getToken(SSgrammarParser.INT, 0)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitListInt" ):
                return visitor.visitListInt(self)
            else:
                return visitor.visitChildren(self)


    class ListDecContext(ListLitContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a SSgrammarParser.ListLitContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def DEC(self):
            return self.getToken(SSgrammarParser.DEC, 0)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitListDec" ):
                return visitor.visitListDec(self)
            else:
                return visitor.visitChildren(self)


    class LsLitContContext(ListLitContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a SSgrammarParser.ListLitContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def listLit(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(SSgrammarParser.ListLitContext)
            else:
                return self.getTypedRuleContext(SSgrammarParser.ListLitContext,i)


        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitLsLitCont" ):
                return visitor.visitLsLitCont(self)
            else:
                return visitor.visitChildren(self)


    class ListStringContext(ListLitContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a SSgrammarParser.ListLitContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def strLit(self):
            return self.getTypedRuleContext(SSgrammarParser.StrLitContext,0)


        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitListString" ):
                return visitor.visitListString(self)
            else:
                return visitor.visitChildren(self)



    def listLit(self, _p:int=0):
        _parentctx = self._ctx
        _parentState = self.state
        localctx = SSgrammarParser.ListLitContext(self, self._ctx, _parentState)
        _prevctx = localctx
        _startState = 8
        self.enterRecursionRule(localctx, 8, self.RULE_listLit, _p)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 110
            self._errHandler.sync(self)
            la_ = self._interp.adaptivePredict(self._input,6,self._ctx)
            if la_ == 1:
                localctx = SSgrammarParser.LsLitStartContext(self, localctx)
                self._ctx = localctx
                _prevctx = localctx

                self.state = 102
                self.match(SSgrammarParser.T__2)
                self.state = 103
                self.listLit(0)
                self.state = 104
                self.match(SSgrammarParser.T__3)
                pass

            elif la_ == 2:
                localctx = SSgrammarParser.ListIntContext(self, localctx)
                self._ctx = localctx
                _prevctx = localctx
                self.state = 106
                self.match(SSgrammarParser.INT)
                pass

            elif la_ == 3:
                localctx = SSgrammarParser.ListIdContext(self, localctx)
                self._ctx = localctx
                _prevctx = localctx
                self.state = 107
                self.match(SSgrammarParser.ID)
                pass

            elif la_ == 4:
                localctx = SSgrammarParser.ListDecContext(self, localctx)
                self._ctx = localctx
                _prevctx = localctx
                self.state = 108
                self.match(SSgrammarParser.DEC)
                pass

            elif la_ == 5:
                localctx = SSgrammarParser.ListStringContext(self, localctx)
                self._ctx = localctx
                _prevctx = localctx
                self.state = 109
                self.strLit(0)
                pass


            self._ctx.stop = self._input.LT(-1)
            self.state = 117
            self._errHandler.sync(self)
            _alt = self._interp.adaptivePredict(self._input,7,self._ctx)
            while _alt!=2 and _alt!=ATN.INVALID_ALT_NUMBER:
                if _alt==1:
                    if self._parseListeners is not None:
                        self.triggerExitRuleEvent()
                    _prevctx = localctx
                    localctx = SSgrammarParser.LsLitContContext(self, SSgrammarParser.ListLitContext(self, _parentctx, _parentState))
                    self.pushNewRecursionContext(localctx, _startState, self.RULE_listLit)
                    self.state = 112
                    if not self.precpred(self._ctx, 5):
                        from antlr4.error.Errors import FailedPredicateException
                        raise FailedPredicateException(self, "self.precpred(self._ctx, 5)")
                    self.state = 113
                    self.match(SSgrammarParser.T__1)
                    self.state = 114
                    self.listLit(6) 
                self.state = 119
                self._errHandler.sync(self)
                _alt = self._interp.adaptivePredict(self._input,7,self._ctx)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.unrollRecursionContexts(_parentctx)
        return localctx

    class StrLitContext(ParserRuleContext):

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser


        def getRuleIndex(self):
            return SSgrammarParser.RULE_strLit

     
        def copyFrom(self, ctx:ParserRuleContext):
            super().copyFrom(ctx)


    class StringContext(StrLitContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a SSgrammarParser.StrLitContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def STRING(self):
            return self.getToken(SSgrammarParser.STRING, 0)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitString" ):
                return visitor.visitString(self)
            else:
                return visitor.visitChildren(self)


    class StrdecContext(StrLitContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a SSgrammarParser.StrLitContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def DEC(self):
            return self.getToken(SSgrammarParser.DEC, 0)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitStrdec" ):
                return visitor.visitStrdec(self)
            else:
                return visitor.visitChildren(self)


    class StrIdContext(StrLitContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a SSgrammarParser.StrLitContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def ID(self):
            return self.getToken(SSgrammarParser.ID, 0)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitStrId" ):
                return visitor.visitStrId(self)
            else:
                return visitor.visitChildren(self)


    class RepeatStrContext(StrLitContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a SSgrammarParser.StrLitContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def strLit(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(SSgrammarParser.StrLitContext)
            else:
                return self.getTypedRuleContext(SSgrammarParser.StrLitContext,i)

        def MUL(self):
            return self.getToken(SSgrammarParser.MUL, 0)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitRepeatStr" ):
                return visitor.visitRepeatStr(self)
            else:
                return visitor.visitChildren(self)


    class ConCatContext(StrLitContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a SSgrammarParser.StrLitContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def strLit(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(SSgrammarParser.StrLitContext)
            else:
                return self.getTypedRuleContext(SSgrammarParser.StrLitContext,i)

        def ADD(self):
            return self.getToken(SSgrammarParser.ADD, 0)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitConCat" ):
                return visitor.visitConCat(self)
            else:
                return visitor.visitChildren(self)


    class StrIndexContext(StrLitContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a SSgrammarParser.StrLitContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def strLit(self):
            return self.getTypedRuleContext(SSgrammarParser.StrLitContext,0)

        def expr(self):
            return self.getTypedRuleContext(SSgrammarParser.ExprContext,0)


        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitStrIndex" ):
                return visitor.visitStrIndex(self)
            else:
                return visitor.visitChildren(self)



    def strLit(self, _p:int=0):
        _parentctx = self._ctx
        _parentState = self.state
        localctx = SSgrammarParser.StrLitContext(self, self._ctx, _parentState)
        _prevctx = localctx
        _startState = 10
        self.enterRecursionRule(localctx, 10, self.RULE_strLit, _p)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 124
            self._errHandler.sync(self)
            token = self._input.LA(1)
            if token in [SSgrammarParser.STRING]:
                localctx = SSgrammarParser.StringContext(self, localctx)
                self._ctx = localctx
                _prevctx = localctx

                self.state = 121
                self.match(SSgrammarParser.STRING)
                pass
            elif token in [SSgrammarParser.ID]:
                localctx = SSgrammarParser.StrIdContext(self, localctx)
                self._ctx = localctx
                _prevctx = localctx
                self.state = 122
                self.match(SSgrammarParser.ID)
                pass
            elif token in [SSgrammarParser.DEC]:
                localctx = SSgrammarParser.StrdecContext(self, localctx)
                self._ctx = localctx
                _prevctx = localctx
                self.state = 123
                self.match(SSgrammarParser.DEC)
                pass
            else:
                raise NoViableAltException(self)

            self._ctx.stop = self._input.LT(-1)
            self.state = 139
            self._errHandler.sync(self)
            _alt = self._interp.adaptivePredict(self._input,10,self._ctx)
            while _alt!=2 and _alt!=ATN.INVALID_ALT_NUMBER:
                if _alt==1:
                    if self._parseListeners is not None:
                        self.triggerExitRuleEvent()
                    _prevctx = localctx
                    self.state = 137
                    self._errHandler.sync(self)
                    la_ = self._interp.adaptivePredict(self._input,9,self._ctx)
                    if la_ == 1:
                        localctx = SSgrammarParser.RepeatStrContext(self, SSgrammarParser.StrLitContext(self, _parentctx, _parentState))
                        self.pushNewRecursionContext(localctx, _startState, self.RULE_strLit)
                        self.state = 126
                        if not self.precpred(self._ctx, 6):
                            from antlr4.error.Errors import FailedPredicateException
                            raise FailedPredicateException(self, "self.precpred(self._ctx, 6)")
                        self.state = 127
                        self.match(SSgrammarParser.MUL)
                        self.state = 128
                        self.strLit(7)
                        pass

                    elif la_ == 2:
                        localctx = SSgrammarParser.ConCatContext(self, SSgrammarParser.StrLitContext(self, _parentctx, _parentState))
                        self.pushNewRecursionContext(localctx, _startState, self.RULE_strLit)
                        self.state = 129
                        if not self.precpred(self._ctx, 5):
                            from antlr4.error.Errors import FailedPredicateException
                            raise FailedPredicateException(self, "self.precpred(self._ctx, 5)")
                        self.state = 130
                        self.match(SSgrammarParser.ADD)
                        self.state = 131
                        self.strLit(6)
                        pass

                    elif la_ == 3:
                        localctx = SSgrammarParser.StrIndexContext(self, SSgrammarParser.StrLitContext(self, _parentctx, _parentState))
                        self.pushNewRecursionContext(localctx, _startState, self.RULE_strLit)
                        self.state = 132
                        if not self.precpred(self._ctx, 4):
                            from antlr4.error.Errors import FailedPredicateException
                            raise FailedPredicateException(self, "self.precpred(self._ctx, 4)")
                        self.state = 133
                        self.match(SSgrammarParser.T__2)
                        self.state = 134
                        self.expr(0)
                        self.state = 135
                        self.match(SSgrammarParser.T__3)
                        pass

             
                self.state = 141
                self._errHandler.sync(self)
                _alt = self._interp.adaptivePredict(self._input,10,self._ctx)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.unrollRecursionContexts(_parentctx)
        return localctx



    def sempred(self, localctx:RuleContext, ruleIndex:int, predIndex:int):
        if self._predicates == None:
            self._predicates = dict()
        self._predicates[3] = self.expr_sempred
        self._predicates[4] = self.listLit_sempred
        self._predicates[5] = self.strLit_sempred
        pred = self._predicates.get(ruleIndex, None)
        if pred is None:
            raise Exception("No predicate with index:" + str(ruleIndex))
        else:
            return pred(localctx, predIndex)

    def expr_sempred(self, localctx:ExprContext, predIndex:int):
            if predIndex == 0:
                return self.precpred(self._ctx, 17)
         

            if predIndex == 1:
                return self.precpred(self._ctx, 16)
         

            if predIndex == 2:
                return self.precpred(self._ctx, 15)
         

            if predIndex == 3:
                return self.precpred(self._ctx, 14)
         

            if predIndex == 4:
                return self.precpred(self._ctx, 13)
         

            if predIndex == 5:
                return self.precpred(self._ctx, 12)
         

            if predIndex == 6:
                return self.precpred(self._ctx, 11)
         

            if predIndex == 7:
                return self.precpred(self._ctx, 10)
         

            if predIndex == 8:
                return self.precpred(self._ctx, 9)
         

            if predIndex == 9:
                return self.precpred(self._ctx, 7)
         

    def listLit_sempred(self, localctx:ListLitContext, predIndex:int):
            if predIndex == 10:
                return self.precpred(self._ctx, 5)
         

    def strLit_sempred(self, localctx:StrLitContext, predIndex:int):
            if predIndex == 11:
                return self.precpred(self._ctx, 6)
         

            if predIndex == 12:
                return self.precpred(self._ctx, 5)
         

            if predIndex == 13:
                return self.precpred(self._ctx, 4)
         




