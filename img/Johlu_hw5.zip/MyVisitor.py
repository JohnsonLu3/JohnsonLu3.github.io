# Johnson Lu 109105138

from SSgrammarVisitor import SSgrammarVisitor
from SSgrammarParser import SSgrammarParser
import math

tempArray = []

syntaxErrLines = []
linesCheck     = []
errorLine      = -1

class MyVisitor(SSgrammarVisitor):


    def __init__(self):
        self.memory = {}

    def setSyntaxError(self, errLines):
        global syntaxErrLines
        syntaxErrLines = errLines

    def checkSyntaxError(self,ctx):
        global errorLine
        line = ctx.start.line
        if(line in syntaxErrLines):
            errorLine = line
            return True

        return False
    def visitAssign(self, ctx):
        name = ctx.ID().getText()
        value = self.visit(ctx.expr())
        self.memory[name] = value
        return value

    def visitAssignStr(self, ctx):
        name = ctx.ID().getText()
        value = self.visit(ctx.strLit())
        self.memory[name] = value
        return value

    def visitAssignList(self, ctx):
        name = ctx.ID().getText()
        value = self.visit(ctx.listLit())
        self.memory[name] = value
        return value

    def visitPrintExpr(self, ctx):
        if(self.checkSyntaxError(ctx)):
            if(errorLine in linesCheck):
                return 0
            else:
                linesCheck.append(errorLine)
                print("SYNTAX ERROR")
                return 0

        value = self.visit(ctx.expr())
        print(value)
        return 0

    def visitPrintStr(self, ctx):
        string = self.visit(ctx.strLit())
        print("'",string,"'", sep="")
        return 0

    def visitInt(self, ctx):
        return ctx.INT().getText()


    def visitStrId(self, ctx):
        name = ctx.ID().getText()
        if name in self.memory:
            return self.memory[name]
        return 0

    def visitString(self, ctx):
        stringVal = ctx.STRING().getText()
        stringVal = stringVal[1:-1]
        return stringVal

    def visitId(self, ctx):
        name = ctx.ID().getText()
        if name in self.memory:
            return self.memory[name]
        return 0

    def visitDec(self, ctx):
        decimal = ctx.DEC().getText()
        return decimal

    def visitMulDiv(self, ctx):
        try:
            left = float(self.visit(ctx.expr(0)))
            right = float(self.visit(ctx.expr(1)))
        except:
            return "SEMANTIC ERROR"

        if ctx.op.type == SSgrammarParser.MUL:
            evalVal = left * right
            if evalVal.is_integer():
                evalVal = int(evalVal)
            return evalVal
        elif ctx.op.type == SSgrammarParser.DIV:
            evalVal = left / right
            if evalVal.is_integer():
                evalVal = int(evalVal)
            return evalVal


    def visitAddSub(self, ctx):
        try:
            left = float(self.visit(ctx.expr(0)))
            right = float(self.visit(ctx.expr(1)))
        except:
            return "SEMANTIC ERROR"

        if ctx.op.type == SSgrammarParser.ADD:
            evalVal = left + right
            if evalVal.is_integer():
                evalVal = int(evalVal)
            return evalVal
        elif ctx.op.type == SSgrammarParser.SUB:
            evalVal = left - right
            if evalVal.is_integer():
                evalVal = int(evalVal)
            return evalVal

    def visitParens(self, ctx):
        return self.visit(ctx.expr())


    def visitConCat(self, ctx):
        try:
            left = self.visit(ctx.strLit(0))
            right = self.visit(ctx.strLit(1))

            if left == None or right == None:
                return  "SEMANTIC ERROR"
            left = str(left)
            right = str(right)
        except:
            return "SEMANTIC ERROR"

        return left + right

    def visitRepeatStr(self, ctx):
        try:
            left = int(self.visit(ctx.strLit(0)))
            right = str(self.visit(ctx.strLit(1)))
        except:
            return "SYNTAX ERROR"

        return left * right

    def visitStrIndex(self, ctx):
        try:
            string = str(self.visit(ctx.strLit()))
            index  = int(self.visit(ctx.expr()))
        except:
            return "SYNTAX ERROR"

        char = string[index]

        return char

    def visitGTLT(self, ctx):
        # > <
        try:
            left = int(self.visit(ctx.expr(0)))
            right = int(self.visit(ctx.expr(1)))
        except:
            return "SEMANTIC ERROR"

        if ctx.op.type == SSgrammarParser.LT:
            if left < right:
                return 1
            else:
                return 0
        elif ctx.op.type == SSgrammarParser.GT:
            if left > right:
                return 1
            else:
                return 0


    def visitGTELTE(self, ctx):
        # >= <=
        try:
            left = int(self.visit(ctx.expr(0)))
            right = int(self.visit(ctx.expr(1)))
        except:
            return "SEMANTIC ERROR"

        if ctx.op.type == SSgrammarParser.LTE:
            if left <= right:
                    return 1
            else:
                    return 0
        elif ctx.op.type == SSgrammarParser.GTE:
            if left <= right:
                return 1
        else:
            return 0

    def visitNotVal(self, ctx):
        try:
            value2Not = int(self.visit(ctx.expr()))
        except:
            return "SEMANTIC ERROR"

        if value2Not != 0:
            value2Not = 0
        else:
            value2Not = 1

        return value2Not

    def visitEQNE(self, ctx):
        # == <>
        try:
            left = int(self.visit(ctx.expr(0)))
            right = int(self.visit(ctx.expr(1)))
        except:
            return "SEMANTIC ERROR"

        if ctx.op.type == SSgrammarParser.EQT:
            if left == right:
                return 1
            else:
                return 0
        elif ctx.op.type == SSgrammarParser.NEQT:
            if left != right:
                return 1
            else:
                return 0

    def visitFDEX(self, ctx):
        # floor divison and expo
        try:
            left = float(self.visit(ctx.expr(0)))
            right = float(self.visit(ctx.expr(1)))
        except:
            return "SEMANTIC ERROR"

        if ctx.op.type == SSgrammarParser.FDIV:
            return math.floor(left / right)
        elif ctx.op.type == SSgrammarParser.EXPO:
            evalVal = left ** right
            if evalVal.is_integer():
                evalVal = int(evalVal)
            return evalVal


    def visitMODOP(self, ctx):
        try:
            left = int(self.visit(ctx.expr(0)))
            right = int(self.visit(ctx.expr(1)))
        except:
            return "SEMANTIC ERROR"

        return left % right

    def visitANDOR(self, ctx):
        try:
            left = int(self.visit(ctx.expr(0)))
            right = int(self.visit(ctx.expr(1)))
        except:
            return "SEMANTIC ERROR"

        if left != 0:
            left = 1

        if right != 0:
            right = 1

        if ctx.op.type == SSgrammarParser.AND:
            if left and right:
                return 1
            else:
                return 0
        elif ctx.op.type == SSgrammarParser.OR:
            if left or right:
                return 1
            else:
                return 0

    def visitIdIndex(self, ctx):
        tempArray = []

        list = self.visit(ctx.expr(0))
        index = int(self.visit(ctx.expr(1)))

        value = list[index]

        return value

    def visitListStart(self, ctx):
        tempArray = []

        list  = self.visit(ctx.expr(0))
        index = int(self.visit(ctx.expr(1)))

        value =list[index]

        return value

    def visitListCont(self, ctx):
        try:
            left  = int(self.visit(ctx.expr(0)))
            right = int(self.visit(ctx.expr(1)))
            tempArray.append(int(left))
            tempArray.append(int(right))

        except:
            tempArray.append(int(self.visit(ctx.expr(1))))

        return tempArray

    def visitListId(self, ctx):
        name = ctx.ID().getText()
        if name in self.memory:
            return self.memory[name]
        return 0

    def visitListInt(self, ctx):
        return ctx.INT().getText()

    def visitLsLitStart(self, ctx):
        tempArray = []
        list  = self.visit(ctx.listLit())
        return list

    def visitLsLitCont(self, ctx):
        try:
            left = int(self.visit(ctx.listLit(0)))
            right = int(self.visit(ctx.listLit(1)))
            tempArray.append(int(left))
            tempArray.append(int(right))

        except:
            tempArray.append(int(self.visit(ctx.listLit(1))))

        return tempArray

    def visitListDec(self, ctx):
        decimal = ctx.DEC().getText()
        return decimal

    def visitListString(self, ctx):
        stringVal = ctx.STRING().getText()

        stringVal = stringVal[1:-1]
        return stringVal
